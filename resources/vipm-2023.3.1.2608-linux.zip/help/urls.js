var g_ContentsURL = "VI%20Package%20Manager%20User%20Guide-toc.htm";
var g_IndexURL = "VI%20Package%20Manager%20User%20Guide-index.htm";
var g_SearchURL = "VI%20Package%20Manager%20User%20Guide-search.htm";
var g_FavoritesURL = "VI%20Package%20Manager%20User%20Guide-favorites.htm";
