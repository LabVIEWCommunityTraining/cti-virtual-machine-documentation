
var MAIN_HELP_PAGE = "index.html";
var g_d2hContextIds = new Array();

 g_d2hContextIds["846"]="addoreditpackagedependencydialog.htm";

 g_d2hContextIds["1007"]="addpalettetolibraryorclass.htm";

 g_d2hContextIds["422"]="configurelabviewportdialog.htm";

 g_d2hContextIds["250"]="definelabviewversiondialog.htm";

 g_d2hContextIds["696"]="editmenu.htm";

 g_d2hContextIds["555"]="editmenu2.htm";

 g_d2hContextIds["568"]="editmenu3.htm";

 g_d2hContextIds["837"]="editingthepalettes1.htm";

 g_d2hContextIds["912"]="filemenu4.htm";

 g_d2hContextIds["776"]="filemenu1.htm";

 g_d2hContextIds["567"]="filemenu3.htm";

 g_d2hContextIds["554"]="filemenu2.htm";

 g_d2hContextIds["695"]="filemenu.htm";

 g_d2hContextIds["700"]="helpmenu.htm";

 g_d2hContextIds["572"]="helpmenu3.htm";

 g_d2hContextIds["779"]="helpmenu1.htm";

 g_d2hContextIds["559"]="helpmenu2.htm";

 g_d2hContextIds["914"]="helpmenu4.htm";

 g_d2hContextIds["991"]="installingvipmviacommandlinewindowsonly.htm";

 g_d2hContextIds["220"]="lastactionresultswindow.htm";

 g_d2hContextIds["833"]="newpackagebuildprojectdialog.htm";

 g_d2hContextIds["219"]="packageactionconfirmationwindow.htm";

 g_d2hContextIds["557"]="packagemenu2.htm";

 g_d2hContextIds["570"]="packagemenu3.htm";

 g_d2hContextIds["697"]="packagemenu.htm";

 g_d2hContextIds["778"]="packagemenu1.htm";

 g_d2hContextIds["884"]="palettecategorybrowserdialog.htm";

 g_d2hContextIds["993"]="palettedefaults.htm";

 g_d2hContextIds["900"]="prebuildcheckproblemreportwindow1.htm";

 g_d2hContextIds["777"]="repositorymenu.htm";

 g_d2hContextIds["561"]="search2.htm";

 g_d2hContextIds["1008"]="specialconsiderationsforsomelabviewdestinations.htm";

 g_d2hContextIds["571"]="toolsmenu3.htm";

 g_d2hContextIds["558"]="toolsmenu2.htm";

 g_d2hContextIds["698"]="toolsmenu.htm";

 g_d2hContextIds["569"]="viewmenu3.htm";

 g_d2hContextIds["556"]="viewmenu2.htm";

 g_d2hContextIds["440"]="vipmiconforlinuxinstallation.htm";

 g_d2hContextIds["788"]="whatdovipmclientsseewhenapackageisdeprecated.htm";

 g_d2hContextIds["699"]="windowmenu2.htm";

 g_d2hContextIds["913"]="windowmenu3.htm";

 g_d2hContextIds["589"]="windowmenu1.htm";

 g_d2hContextIds["588"]="windowmenu.htm";
